<?php
$zitate = [
		 23 => [
				"color" => "#F5A927",
				"zitat" => "Gerade an Weihnachten gilt: Wer Visionen haben will darf nicht an den Drogen sparen.",
				"position" => "20px 25px",
		],
		8 => [
				"color" => "#B837F8",
				"zitat" => "<Ey! Gewalt ist die Sprache der Dummen!> rufe ich. <Nee>, sagt das Känguru und denkt einen Moment nach. <Englisch!>",
				"position" => "20px 730px",
		],
		15 => [
				"color" => "#24BCBC",
				"zitat" => "<Ach, richtig, falsch...> sagt das Känguru, <das sind doch bürgerliche Kategorien.>",
				"position" => "40px 890px",
		],
		16 => [
				"color" => "#22B03C",
				"zitat" => "<Aber wenn du irgendjemandem hiervon erzählst, wird Jesus nicht der einzige bleiben den man an Weihnachten gekreuzigt hat.> sagt das Känguru. - <Die Kreuzigung war an Halloween!>",
				"position" => "20px 1050px",
		],
		21 => [
				"color" => "#B0226B",
				"zitat" => "Wie ich mal groß einkaufen war, Steh vor dem Lidl, kurz nach acht. Leider hat er schon dichtgemacht. Auf einem Schild les' ich tags drauf: Sonntag ham wir gar nicht auf.",
				"position" => "210px 20px",
		],
		6 => [
				"color" => "#E3FA3B",
				"zitat" => "Man muss dem Mädchen zugestehen, dass eine blinkende rote Nase im Gesicht, die Glaubwürdigkeit des Zeugen nicht gerade in einem goldenen Licht erstrahlen lässt.",
				"position" => "370px 25px",
		],
		19 => [
				"color" => "#FA4E3B",
				"zitat" => "<Aber nicht zu Lidl!> ruft mir das Känguru hinterher. <Die Arbeitsbedingungen da sind unter...>",
				"position" => "525px 20px",
		],
		1 => [
				"color" => "#FF2DAC",
				"zitat" => "<Warum tue ich das nochmal?> fragt das Känguru. - <Weil du nach dem siebten Glühwein behauptet hast,die heiligen drei Könige hätten Weihrauch, Myrrhe und Benzingutscheine gebracht und ich gesagt habe: wetten dass nicht!>",
				"position" => "190px 700px",
		],
		9 => [
				"color" => "#5A22CB",
				"zitat" => "<Du hast gesoffen auf Arbeit?> - <Ja aber nur Vodka.> - <Vodka?> - <Nie mehr als zwei Flaschen pro Tag.> - <Zwei Flaschen pro Tag?> - <ALTER! Ruf du mal den ganzen Tag wildfremde Menschen an und frag sie nach ihrer Meinung zur FDP.>",
				"position" => "160px 820px",
		],
		4 => [
				"color" => "#6EF584",
				"zitat" => "<Aber wie soll ich denn ein Wort wie Dialektik, das alles und nichts bedeuten kann, in verständliches Deutsch übersetzen?> - <Lass es einfach weg.> sagt das Känguru. <Dialektik ist meines Erachtens eh nur eine philosophische Luftblase.>",
				"position" => "190px 965px",
		],
		24=> [
				"color" => "#961515",
				"zitat" => "Ich opfere dieses köstliche Gebäck Johannes dem Säufer, dem Erfinder des Glühweins. Führe uns in Versuchung. Prost!",
				"position" => "170px 1090px",
		],
		12 => [
				"color" => "#100D6B",
				"zitat" => "Kennen Sie Deutschland? Im Süden die Berge, im Norden das Meer und dazwischen Teer.>",
				"position" => "30px 1210px",
		],
		2 => [
				"color" => "#F5A927",
				"zitat" => "Rechts vor links. Das ist ein reaktionärekonservatives Unterdrückungsmuster, manifestiert in der StVO.",
				"position" => "330px 750px",
		],
		14 => [
				"color" => "#E53313",
				"zitat" => "Aber gibt's echt nur Teer? Es gibt doch noch mehr! Ja, genau! Stau.>",
				"position" => "345px 900px",
		],
		22 => [
				"color" => "#E3FA3B",
				"zitat" => "Nachdem man entschied, der Krieg würde sich nicht mehr lohnen. Fasste man einen folgenschweren Entschluss. Man teilte das Land in vier Besatzungszonen. T-Mobile, O2, vodafone und e-plus. Ein gewisser Romeo war zu dieser Zeit auf Brautschau und traf eine gewisse Julia, sie trug helles Blaukraut-Blau. Romeo trug wie immer dezentes Magenta. Ach herrje. Ja, der Kenner erkennt da - wie unangenehm - schon das Problem denn sie fanden sich zwar beide ziemlich geil doch sie war eine O2 und er ein T-Mobile.",
				"position" => "325px 1050px",
		],
		7 => [
				"color" => "#B0226B",
				"zitat" => "Damit wird das Zeitenporträt erst komplett. Parkaus, Mikrowelle, digitaler Bilderrahmen: HÄSSLICH, STINKEND, GESCHMACKSNEUTRAL, KREBSERREGEND, TEUER UND VÖLLIG SINNLOS!",
				"position" => "330px 1200px",
		],
		17 => [
				"color" => "#22B03C",
				"zitat" => "<Lieber fünf mal nachgefragt, als ein mal nachgedacht.>",
				"position" => "500px 780px",
		],
		18 => [
				"color" => "#35EAFA",
				"zitat" => "<Der Dativ ist dem Genitiv sein Tod> - Meister Yoda",
				"position" => "480px 930px",
		],
		10 => [
				"color" => "#881AD7",
				"zitat" => "<Niemand hat die Absicht, eine Mauer zu errichten.> - Bob der Baumeister",
				"position" => "500px 1080px",
		],
		20 => [
				"color" => "#F6A440",
				"zitat" => "<Es steht im Augenblick 1:1. Aber es hätte auch umgekehrt lauten können.> - Die Relativitätstheorie",
				"position" => "300px 150px",
		],
		11 => [
				"color" => "#F3A193",
				"zitat" => "<Vertrauen ist gut, Kontrolle ist besser.> - LIDL",
				"position" => "460px 140px",
		],
		3 => [
				"color" => "#5A22CB",
				"zitat" => "<Hier stehe ich. Ich kann nicht anders.> - Die Freiheitsstatue",
				"position" => "480px 1225px",
		],
		13 => [
				"color" => "#EB8016",
				"zitat" => "<Wenn man ein 0:2 kassiert, dann ist ein 1:1 nicht mehr möglich.> - Satz den Pythagoras",
				"position" => "180px 1230px",
		],
		5 => [
				"color" => "#B837F8",
				"zitat" => "<Ich will ein Kind von dir.> - Die Bundeswehr",
				"position" => "120px 120px",
		]
		
];
?>
<html>
	<head>
		<meta charset="UTF-8">
		<link href="css/style.css" rel="stylesheet" type="text/css"/>
	<script type="text/javascript">
		function showAlert(text) {
			alert(text);
			}
	</script>
	</head>
	<body>
	<?php foreach($zitate as $key => $value) { 
	if(time()>= strtotime("2015-12-".$key)){
		
	
		?>
	<a onClick="showAlert(<?= "'" . $value["zitat"] . "'"?>)">
	
		<div class="kreis" style="background-color: <?= $value["color"]?>; margin: <?= $value["position"]?>">
		<div class="number">
		<?= $key?>
		</div>
		</div>
	</a>
	
		<?php } else {?>
				<div class="kreis" style="background-color: <?= $value["color"]?>; margin: <?= $value["position"]?>">
				<div class="number">
		<?= $key?>
		</div>
		</div>
		<?php 
		}
		} ?>
	</body>
</html>